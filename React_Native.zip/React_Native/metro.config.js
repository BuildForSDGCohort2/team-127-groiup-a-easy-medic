module.exports = {
  transformer: {
    assetPlugins: ["expo-asset/tools/hashAssetFiles"]
  },
  resolver: {
    assetExts: ["html", "txt", "db", "ttf", "png"]
  }
};
