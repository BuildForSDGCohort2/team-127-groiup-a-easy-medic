import React, { Component } from "react";
import {
  StyleSheet,
  PixelRatio,
  Image,
  KeyboardAvoidingView,
  TouchableHighlight,
  TextInput,
  Button,
  Alert,
  Text,
  View
} from "react-native";

class ResultScreen extends Component {
  render() {
    return (
      <View>
        <View>
          <TouchableHighlight>
            <Text>GO BACK</Text>
          </TouchableHighlight>
        </View>
      </View>
    );
  }
}

export default ResultScreen;
